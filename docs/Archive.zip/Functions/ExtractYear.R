# --------------------------------------
# FUNCTION extract_year
# required packages: none
# description:
# inputs:
# outputs:
########################################

# function body
extract_year <- function(file_name) {
  # Use regex to extract the year (YYYY) from the date part (YYYY-MM)
  year <- sub(".*(\\d{4})-\\d{2}.*", "\\1", file_name)
  return(year)
}

 # end of function extract_year
# --------------------------------------
# extract_year()
