# --------------------------------------
# FUNCTION abundance
# required packages: none
# description:
# inputs:
# outputs:
########################################

# function body
  abundance <- function(clean_data_result) {
    # Calculate the number of rows (individuals) in the dataset
    abundance <- length(clean_data_result)
    
    # Return the abundance
    return(abundance)
  }

 # end of function abundance
# --------------------------------------
# abundance()
