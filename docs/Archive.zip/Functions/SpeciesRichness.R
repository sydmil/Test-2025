# --------------------------------------
# FUNCTION species_richness
# required packages: none
# description:
# inputs:
# outputs:
########################################


# function body
  species_richness <- function(clean_data_result) {
    # Get the unique species from the 'scientificName' column
    unique_species <- unique(clean_data_result)
    
    # Calculate the number of unique species
    richness <- length(unique_species)
    
    # Return the species richness
    return(richness)
  }
  


 # end of function species_richness
# --------------------------------------
# species_richness()
