# --------------------------------------
# FUNCTION clean_data
# required packages: none
# description:
# inputs:
# outputs:
########################################


# function body
clean_data <- function(data) {
  # Remove rows with any missing values (NA) across all columns
  cleaned_data <- na.omit(data$scientificName)
  return(cleaned_data)
}


 # end of function clean_data
# --------------------------------------
# clean_data()
