

library(upscaler)
library(devtools)
library(ggplot2)
    

 ####### build FUNCTIONS here
    
    build_function(c("clean_data",
                   "extract_year",
                   "abundance",
                   "species_richness")) # creates an R script template for the function

    
    ##################### For Loop
    
    setwd("~/Desktop/CompBio2025/NEON_count-landbird")
    # Get a list of all subdirectories (years) within the main folder
    year_folders <- list.files()
    years<-list()
    
    # Initialize an empty data frame to hold the output summary statistics
    output_summary <- data.frame(
      file_name = character(),
      abundance = numeric(),
      species_richness = numeric(),
      year = numeric()
    )
    
    # Set the path for your functions (assuming 'Functions' is the directory where functions are stored)
    setwd("~/Desktop/CompBio2025/Functions")
    
    # Load all the custom functions (assuming all functions are in separate files)
    source("CleanData.R")
    source("ExtractYear.R")
    source("Abundance.R")
    source("SpeciesRichness.R")
    
    # Change back to the main working directory after loading functions
    setwd("~/Desktop/CompBio2025/NEON_count-landbird")
    
    
    for (i in 1:10) {
      setwd(year_folders[i])
      
      countdata_files <- list.files(pattern = "countdata.*\\.csv$", full.names = FALSE)
      
      years[[i]] <- countdata_files  # use [[i]] to assign to list
      
      setwd("~/Desktop/CompBio2025/NEON_count-landbird")
    }
    
   
    
    #### Loop to create output summary
      
      # Loop through each file
      for (i in 1:10) {
        
        setwd(year_folders[i])
        # Read the CSV file into the environment
        data <- read.csv(years[[i]])
        
        # Clean the data using your 'clean_data' function
        clean_data_result <- clean_data(data)
        
        # Extract year information using 'extract_year' (if applicable)
        extracted_year <- extract_year(years[[i]])  # Assuming it extracts year from the file
        
        # Calculate abundance using the 'abundance' function
        abundance_value <- abundance(clean_data_result)
        
        # Calculate species richness using the 'species_richness' function
        species_richness_value <- species_richness(clean_data_result)
        
        
        # Store the regression results into the summary statistics
        output_summary <- rbind(output_summary, data.frame(
          abundance = abundance_value,
          species_richness = species_richness_value,
          year = extracted_year
        ))
        
        setwd("~/Desktop/CompBio2025/NEON_count-landbird")
      }
    
    # Save the summary statistics to a CSV file
    write.csv(output_summary, "summary_statistics.csv", row.names = FALSE)
    
    
    
    
    
    
  #Make abundance histogram
   abundance_plot <- ggplot(output_summary, aes(x = factor(year), y = abundance)) +
      geom_bar(stat = "identity", fill = "steelblue") +
      labs(
        title = "Bird Abundance by Year",
        x = "Year",
        y = "Total Abundance"
      ) +
      theme_minimal()
    
  abundance_plot
    
    
  #Make species richness histogram
  richness_plot <- ggplot(output_summary, aes(x = factor(year), y = species_richness)) +
      geom_bar(stat = "identity", fill = "steelblue") +
      labs(
        title = "Bird Species Richness by Year",
        x = "Year",
        y = "Total Species Richness"
      ) +
      theme_minimal()
  
  richness_plot
    
    
#####Regression model
  
  model <- lm(species_richness ~ abundance, data = output_summary)
  
  # Summary of the model
  summary(model)

  
#Plot of regression model
  
  ggplot(output_summary, aes(x = abundance, y = species_richness)) +
    geom_point() +
    geom_smooth(method = "lm", se = TRUE, color = "blue") +
    labs(
      title = "Species Richness vs. Abundance",
      x = "Abundance",
      y = "Species Richness"
    ) +
    theme_minimal()
    
    
    
 